<?php $__env->startSection('content'); ?>
<div class="post-details">
    <h2><?php echo e($post->title); ?></h2>
    <p><strong>Category:</strong> <?php echo e($post->category->name); ?></p>
    <hr>
    <p><?php echo e($post->content); ?></p>

    <a href="<?php echo e(url('/blog')); ?>" class="btn btn-primary mt-3">⬅ Back to Blog</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Laravel Herd\laravel new\assignment-2\resources\views/posts/show.blade.php ENDPATH**/ ?>