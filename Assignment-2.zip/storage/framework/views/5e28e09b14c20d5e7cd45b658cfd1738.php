<?php $__env->startSection('content'); ?>
<h2>Posts</h2>

<a href="<?php echo e(route('posts.create')); ?>" class="btn btn-success mb-3">Add Post</a>

<table class="table">
    <tr><th>ID</th><th>Title</th><th>Category</th></tr>
    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($post->id); ?></td>
            <td><?php echo e($post->title); ?></td>
            <td><?php echo e($post->category->name); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<?php echo e($posts->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Laravel Herd\laravel new\assignment-2\resources\views/posts/index.blade.php ENDPATH**/ ?>