<?php $__env->startSection('content'); ?>
<h2>Categories</h2>

<a href="<?php echo e(route('categories.create')); ?>" class="btn btn-success mb-3">Add Category</a>

<table class="table">
    <tr><th>ID</th><th>Name</th><th>Slug</th></tr>
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($category->id); ?></td>
            <td><?php echo e($category->name); ?></td>
            <td><?php echo e($category->slug); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<?php echo e($categories->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Laravel Herd\laravel new\assignment-2\resources\views/categories/index.blade.php ENDPATH**/ ?>