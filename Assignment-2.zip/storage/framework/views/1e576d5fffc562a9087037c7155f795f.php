<?php $__env->startSection('content'); ?>
<style>
    .hero {
        text-align: center;
        padding: 80px 20px;
        background: linear-gradient(135deg, #1abc9c, #3498db);
        color: white;
        border-radius: 15px;
    }
    .hero h1 {
        font-size: 3rem;
        margin-bottom: 15px;
    }
    .hero p {
        font-size: 1.2rem;
        margin-bottom: 30px;
    }
    .btn-custom {
        background: #2c3e50;
        color: #ecf0f1;
        padding: 10px 20px;
        border-radius: 25px;
        font-size: 16px;
        text-decoration: none;
        margin: 5px;
        transition: 0.3s;
    }
    .btn-custom:hover {
        background: #1abc9c;
        color: #fff;
    }
    .features {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 20px;
        margin-top: 50px;
    }
    .card {
        background: #f9f9f9;
        padding: 20px;
        border-radius: 15px;
        box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        transition: transform 0.3s;
        text-align: center;
    }
    .card:hover {
        transform: scale(1.05);
    }

   

</style>

<div class="hero">
    <h1 id="welcome-text">Welcome to My Blog Project</h1>
    <p>Manage Categories, Create Posts, and Explore Blog Articles</p>
    <a href="<?php echo e(route('categories.index')); ?>" class="btn-custom">View Categories</a>
    <a href="<?php echo e(route('posts.index')); ?>" class="btn-custom">View Posts</a>
    <a href="<?php echo e(url('/blog')); ?>" class="btn-custom">Read Blog</a>
</div>

<div class="features">
    <div class="card">
        <h3>📂 Manage Categories</h3>
        <p>Add and organize blog categories easily with validation.</p>
    </div>
    <div class="card">
        <h3>📝 Create Posts</h3>
        <p>Write posts linked to categories with clean form handling.</p>
    </div>
    <div class="card">
        <h3>🌍 Blog Frontend</h3>
        <p>Show categories with their respective posts on the frontend page.</p>
    </div>
</div>

<script>
    // Simple JS text animation
    const text = "Welcome to My Blog Project";
    let i = 0;
    function typingEffect() {
        if (i < text.length) {
            document.getElementById("welcome-text").innerHTML = text.substring(0, i+1);
            i++;
            setTimeout(typingEffect, 100);
        }
    }
    typingEffect();
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Laravel Herd\laravel new\assignment-2\resources\views/home.blade.php ENDPATH**/ ?>