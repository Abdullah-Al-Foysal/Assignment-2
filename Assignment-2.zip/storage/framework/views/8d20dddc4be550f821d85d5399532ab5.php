<?php $__env->startSection('content'); ?>
<h2>Blog</h2>
<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <h3><?php echo e($category->name); ?></h3>
    <ul>
        <?php $__currentLoopData = $category->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <strong><?php echo e($post->title); ?></strong> <br>
                <?php echo e(Str::limit($post->content, 100)); ?> 
                <a href="<?php echo e(route('blog.show', $post->id)); ?>" class="btn btn-link">Read More</a>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Laravel Herd\laravel new\assignment-2\resources\views/blog.blade.php ENDPATH**/ ?>