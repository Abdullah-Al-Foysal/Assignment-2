@extends('layouts.app')

@section('content')
<h2>Add Category</h2>

@if ($errors->any())
    <div class="alert alert-danger">
        <ul>@foreach ($errors->all() as $error) <li>{{ $error }}</li> @endforeach</ul>
    </div>
@endif

<form action="{{ route('categories.store') }}" method="POST">
    @csrf
    <input type="text" name="name" placeholder="Category Name" class="form-control mb-2">
    <input type="text" name="slug" placeholder="Slug" class="form-control mb-2">
    <button type="submit" class="btn btn-primary">Save</button>
</form>
@endsection
