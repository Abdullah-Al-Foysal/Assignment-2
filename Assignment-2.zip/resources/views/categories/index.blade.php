@extends('layouts.app')

@section('content')
<h2>Categories</h2>

<a href="{{ route('categories.create') }}" class="btn btn-success mb-3">Add Category</a>

<table class="table">
    <tr><th>ID</th><th>Name</th><th>Slug</th></tr>
    @foreach($categories as $category)
        <tr>
            <td>{{ $category->id }}</td>
            <td>{{ $category->name }}</td>
            <td>{{ $category->slug }}</td>
        </tr>
    @endforeach
</table>

{{ $categories->links() }}
@endsection
