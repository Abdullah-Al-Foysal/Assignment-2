@extends('layouts.app')

@section('content')
<div class="post-details">
    <h2>{{ $post->title }}</h2>
    <p><strong>Category:</strong> {{ $post->category->name }}</p>
    <hr>
    <p>{{ $post->content }}</p>

    <a href="{{ url('/blog') }}" class="btn btn-primary mt-3">⬅ Back to Blog</a>
</div>
@endsection
