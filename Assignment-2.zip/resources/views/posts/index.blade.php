@extends('layouts.app')

@section('content')
<h2>Posts</h2>

<a href="{{ route('posts.create') }}" class="btn btn-success mb-3">Add Post</a>

<table class="table">
    <tr><th>ID</th><th>Title</th><th>Category</th></tr>
    @foreach($posts as $post)
        <tr>
            <td>{{ $post->id }}</td>
            <td>{{ $post->title }}</td>
            <td>{{ $post->category->name }}</td>
        </tr>
    @endforeach
</table>

{{ $posts->links() }}
@endsection
