@extends('layouts.app')

@section('content')
<h2>Add Post</h2>

@if ($errors->any())
    <div class="alert alert-danger">
        <ul>@foreach ($errors->all() as $error) <li>{{ $error }}</li> @endforeach</ul>
    </div>
@endif

<form action="{{ route('posts.store') }}" method="POST">
    @csrf
    <input type="text" name="title" placeholder="Post Title" class="form-control mb-2">
    <textarea name="content" placeholder="Post Content" class="form-control mb-2"></textarea>

    <select name="category_id" class="form-control mb-2">
        <option value="">Select Category</option>
        @foreach($categories as $category)
            <option value="{{ $category->id }}">{{ $category->name }}</option>
        @endforeach
    </select>

    <button type="submit" class="btn btn-primary">Save</button>
</form>
@endsection
