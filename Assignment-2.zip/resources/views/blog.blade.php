@extends('layouts.app')

@section('content')
<h2>Blog</h2>
@foreach($categories as $category)
    <h3>{{ $category->name }}</h3>
    <ul>
        @foreach($category->posts as $post)
            <li>
                <strong>{{ $post->title }}</strong> <br>
                {{ Str::limit($post->content, 100) }} 
                <a href="{{ route('blog.show', $post->id) }}" class="btn btn-link">Read More</a>
            </li>
        @endforeach
    </ul>
@endforeach
@endsection
