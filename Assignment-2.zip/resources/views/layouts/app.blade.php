<!DOCTYPE html>
<html>
<head>
    <title>Laravel Blog</title>
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
    <link rel="stylesheet" href="https://matcha.mizu.sh/matcha.css">
    <link rel="stylesheet" href="https://matcha.mizu.sh/@syntax-highlighting.css">
    <link rel="stylesheet" href="https://matcha.mizu.sh/matcha.lite.css">
    <link rel="stylesheet" href="https://matcha.mizu.sh/matcha.utilities.css">
    <link rel="stylesheet" href="https://matcha.mizu.sh/matcha.istanbul.css">


    <style>
        body { font-family: Arial, sans-serif; }
        .navbar { background: #2c3e50; padding: 10px; }
        .navbar a { color: #ecf0f1; margin: 0 10px; text-decoration: none; font-weight: bold; }
        .navbar a:hover { color: #1abc9c; }
        footer { background: #f4f4f4; padding: 15px; margin-top: 20px; text-align: center; font-size: 14px; }


        
        footer {
            background: #2c3e50;
            color: #ecf0f1;
            padding: 25px;
            margin-top: 30px;
            text-align: center;
            font-size: 20px;   /* 🔥 Bigger font size */
            font-weight: bold; /* 🔥 Make it bold */
            border-top: 5px solid #1abc9c;
        }
        footer strong {
            color: #1abc9c; /* Highlight your name */
            font-size: 22px; /* Slightly bigger name */
        }
    </style>
</head>
<body>
    {{-- Navigation Menu --}}
    <div class="navbar">
        <a href="{{ url('/') }}">Home</a>
        <a href="{{ route('categories.index') }}">Categories</a>
        <a href="{{ route('posts.index') }}">Posts</a>
        <a href="{{ url('/blog') }}">Blog</a>
    </div>

    {{-- Page Content --}}
    <div class="container mt-4">
        @yield('content')
    </div>

    {{-- Footer with Assignment Info --}}
    <footer>
        Assignment submitted by <strong>Abdullah Al Foysal</strong> <br>
        📧 Email: foysalit6@gmail.com | 📞 Phone: +880 1914 241009
    </footer>
</body>


<script src="https://mizu.sh/client.js" defer></script>
</html>
