<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\PostController;



// Show single blog post
Route::get('/blog/{post}', [PostController::class, 'show'])->name('blog.show');

Route::resource('categories', CategoryController::class);
Route::resource('posts', PostController::class);

Route::get('/blog', function() {
    $categories = \App\Models\Category::with('posts')->get();
    return view('blog', compact('categories'));
});

Route::get('/', function () {
    return view('home');
});

